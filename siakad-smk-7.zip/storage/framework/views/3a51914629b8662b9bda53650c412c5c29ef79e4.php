<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        Anything you want
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="https://owenwattimena.github.io"  target="_blank">Company</a>.</strong> All rights reserved.
</footer>
<?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/admin/templates/footer.blade.php ENDPATH**/ ?>