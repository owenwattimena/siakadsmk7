
<?php $__env->startSection('title'); ?>
<h1>
    Nilai
    <small>Control panel</small>
</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li><a href="<?php echo e(route('dashboard-siswa')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li class="active"><i class="fa fa-dashboard"></i> Nilai</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="box box-primary">
    <div class="box-header with-border">
        <h3 class="box-title">Data Belajar Siswa</h3>
    </div>
    <div class="box-body">
        <div class="margin padding">
            <form action="<?php echo e(route('dashboard-siswa.nilai')); ?>" method="post" class="form-horizontal">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="semester_id" class="col-sm-6 control-label">Tahun Akademik</label>
                    <div class="col-sm-3">
                        <select name="semester_id" id="semester_id" class="form-control">
                            <?php $__currentLoopData = $listSemester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->tahun_pelajaran); ?> - <?php echo e($item->jenis_semester % 2 == 0 ? 'Genap' : 'Ganjil'); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-sm-3">
                        <button type="submit"class="btn btn-primary">Pilih</button>
                    </div>
                </div>
            </form>
        </div>
        <?php if(isset($dataBelajar)): ?>        
        <div class="box-body col-md-12" align="right" >  
            <a href="<?php echo e(route('dashboard-siswa.donwload-nilai', [$semesterId, 'cetak' => false])); ?>" class="btn btn-flat btn-warning" value="Download Nilai Semester"><i class="fa fa-download"></i> Download</a>
            <a href="<?php echo e(route('dashboard-siswa.donwload-nilai', [$semesterId, 'cetak' => true],)); ?>" class="btn btn-flat btn-info" value="Cetak Nilai Semester"><i class="fa fa-print"></i> Cetak</a>
          </div>
        <table class="table table-condensed">
            <tr>
                <th style="width: 10px">#</th>
                <th>Matapelajaran</th>
                <th>Nilai Pengetahuan</th>
                <th>Nilai Keterampilan</th>
                <th>Nilai Akhir</th>
                <th>Predikat</th>
            </tr>
            <?php $__currentLoopData = $dataBelajar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$key); ?></td>
                <td><?php echo e($value->nama); ?></td>        
                <td><?php echo e($value->nilai_pengetahuan); ?></td>
                <td><?php echo e($value->nilai_ketrampilan); ?></td>
                <td><?php echo e($value->nilai_akhir); ?></td>
                <td><?php echo e($value->predikat); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/siswa/nilai.blade.php ENDPATH**/ ?>