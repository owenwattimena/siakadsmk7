<html>
<head>
    <title>Cetak Nilai <?php echo e(''); ?></title>
</head>
<body>
    <style type="text/css">
        table {
            width: 100%;
        }

        table,
        th,
        td {
            /* border: 1px solid black; */

        }

        th,
        td {
            padding: 5px;
            text-align: left;
            vertical-align: middle;
            border-bottom: 1px solid #ddd;
            font-size: 12px;
        }

        th {
            border-top: 1px solid #ddd;
            height: 20px;
            background-color: #ddd;
            text-align: center;
        }

    </style>
    <center>
        <font size="14">HASIL BELAJAR SISWA<br>
            SMK NEGERI 7 AMBON<br>
            TAHUN AKADEMIK <?php echo e($kelas->tahun_pelajaran); ?></font>
        <br>
        <hr>
        <br>
    </center>

    <?php if(!isset($kelaspeserta)): ?>

    <table>
        <tbody>
            <tr>
                <td style="width: 150px">Mata Pelajaran</td>
                <td><span class="badge bg-light-white">: <?php echo e($kelas->mapel); ?></span></td>
            </tr>
            <tr>
                <td>SKS</td>
                <td><span class="badge bg-yellow">: <?php echo e($kelas->mapel_skm); ?></span></td>
            </tr>
            <tr>
                <td>Kelas</td>
                <td><span class="badge bg-yellow">:<?php echo e($kelas->paket_semester == 1 || $kelas->paket_semester == 2 ? 'X' : ''); ?><?php echo e($kelas->kelas_nama); ?></span></td>
            </tr>
            <tr>
                <td>Semester</td>
                <td><span class="badge bg-yellow">: <?php echo e($kelas->mapel_semester); ?></span></td>
            </tr>

        </tbody>
    </table>
    <?php endif; ?>
    <br>
    <table>
        <thead>
            <tr>
                <th>No.</th>
                <th>NIS</th>
                <th>NAMA</th>
                <th>N. Raport Pengetahuan</th>
                <th>Predikat Pengetahuan</th>
                <th>N. Raport Ketrampilan</th>
                <th>Predikat Ketrampilan</th>
            </tr>
        </thead>
        <tbody>
            <?php if(! empty($kelasPeserta)): ?>
            <?php $i=1;foreach ($kelasPeserta as $itemPeserta):  ?>
            <?php
            ?>
            <tr>
                <td align="center"><?php echo e($i); ?></td>
                <td align="center"><?php echo e($itemPeserta->nis); ?></td>
                <td><?php echo e($itemPeserta->nama); ?></td>
                <td align="right"><?php echo e($itemPeserta->n_raport_pengetahuan); ?></td>
                <td align="right"><?php echo e($itemPeserta->predikat_pengetahuan); ?></td>
                <td align="right"><?php echo e($itemPeserta->n_raport_ketrampilan); ?></td>
                <td align="center"><?php echo e($itemPeserta->predikat_ketrampilan); ?></td>
            </tr>
            <?php $i++; endforeach  ?>
            <?php endif; ?>
        </tbody>
    </table>
    <br>
    <table border="0">
        <tr>
            <td width="70%" align="center"></td>
            <td align="center">Ambon, <?php echo e($today); ?></td>
        </tr>
        <tr height="60px">
            <td width="70%" align="center"></td>
            <td></td>
        </tr>
        <tr>
            <td width="70%" align="center"></td>
            <td align="center"><br><br><br><?php if(!empty($kelas->nama_guru)): ?><u><?php echo e($kelas->nama_guru); ?></u><br><?php echo e(!empty($kelas->nign) ? 'NIP. ' . $kelas->nip ?? '-' : ''); ?> <?php else: ?> _________________________ <?php endif; ?></td>
        </tr>
    </table>
</body>
</html>
<?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/guru/cetak-nilai.blade.php ENDPATH**/ ?>