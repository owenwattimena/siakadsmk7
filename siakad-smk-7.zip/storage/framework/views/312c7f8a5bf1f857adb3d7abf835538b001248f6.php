
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
<h1>
    Saran Siswa
    <small>Control panel</small>
</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li class="active">Saran</li>
</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="box">
        <div class="box-header">
            <h3 class="box-title">Saran Siswa</h3>
            <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#modal-default"><i class="fa fa-plus"></i> Buat</button>
            <div class="modal fade" id="modal-default">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form action="<?php echo e(route('dashboard-siswa.saran')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <h4 class="modal-title">Buat Saran</h4>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="judul">Judul</label>
                                    <input type="text" class="form-control" id="judul" name="judul" placeholder="[Judul]">
                                </div>
                                <div class="form-group">
                                    <label for="isi">Isi Saran</label>
                                    <textarea class="form-control" id="isi" name="isi" placeholder="[Isi Saran]"></textarea>
                                </div>
                                
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-primary">Simpan</button>
                            </div>
                        </form>
                    </div>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
            </div>
        </div>
        <div class="box-body">
            <div class="table-responsive">
                <table id="table" class="table">
                    <thead>
                        <tr>
                            <th style="width: 50px">#</th>
                            <th>Judul</th>
                            <th>Isi</th>
                            <th style="width: 150px">Pilihan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $no = 1;
                        ?>
                        <?php $__currentLoopData = $saran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                <td><?php echo e($no); ?></td>
                                <td><?php echo e($item->judul); ?></td>
                                <td><?php echo e($item->isi); ?></td>
                                <td>
                                    <button onclick="return setValue(`<?php echo e($item->id); ?>`, `<?php echo e($item->judul); ?>`, `<?php echo e($item->isi); ?>`)" class="btn btn-sm bg-yellow" data-toggle="modal" data-target="#modal-default-edit"><i class="fa fa-edit"></i> Edit</button>                                      
                                    <form action="<?php echo e(route('dashboard-siswa.saran-delete', $item->id)); ?>" method="POST" style="display: inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button class="btn btn-sm bg-red" onclick="return confirm('Yakin ingin menghapus saran dan masukan')"> <i class="fa fa-trash"></i> Hapus</button>
                                    </form>
                                </td>
                            </tr>
                            <?php
                                $no++;
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modal-default-edit">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="<?php echo e(route('dashboard-siswa.saran-update')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <input type="hidden" name="id" id="id-edit">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <h4 class="modal-title">Edit Saran</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="judul">Judul</label>
                            <input type="text" class="form-control" id="judul-edit" name="judul" placeholder="[Judul]">
                        </div>
                        <div class="form-group">
                            <label for="isi">Isi Saran</label>
                            <textarea class="form-control" id="isi-edit" name="isi" placeholder="[Isi Pengumuman]"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script src="<?php echo e(asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script>
    $('#table').DataTable({
        "pageLength": 50
    });
    function setValue(id, judul, isi)
    {
        $('#id-edit').val(id);
        $('#judul-edit').val(judul);
        $('#isi-edit').val(isi);
    }
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/siswa/saran.blade.php ENDPATH**/ ?>