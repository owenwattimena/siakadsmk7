
<?php $__env->startSection('title'); ?>
<h1>
    Registrasi Kelas Semester
    <small>Control panel</small>
</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li class="active">Registrasi Siswa Semester</li>
</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="margin padding">
    <div class="box">
        <div class="box-header">
            <h3 class="box-title">Daftar Kelas Teregistrasi Pada Semester Aktif</h3>
            <!-- /.modal -->
        </div>
        <!-- /.box-header -->
        <?php $serviceKelas = app('App\Services\Kelas'); ?>
        <div class="box-body">
            <h3><?php echo e($peserta->first()->mapel_kuri_id); ?>-<?php echo e($peserta->first()->mapel); ?> | Kelas <?php echo e($serviceKelas->kelasSemester($peserta->first()->paket_semester,$peserta->first()->nama_kelas)); ?></h3>
            <form action="<?php echo e(route('nilai.import', $kelasId)); ?>" class="form-horizontal" method="post" enctype="multipart/form-data">
                <table class="table">
                    <tbody>  
                        <tr >
                            <td colspan="2" >
                                1. Gunakan Tombol "Download Peserta Kelas" untuk mendownload format file Upload.<br>
                                2. Upload file dalam ekstensi *.xlsx, *.xls, *.csv dan format sesuai dengan format file yang didownload.
                            </td>
                        </tr>                     
                        <tr>
                            <td width="250px"><input type="file" name="import_file" required /></td>
                            <td align="left"><button type="submit" class="btn btn-primary">Import Nilai</button></td>     
                        </tr>                      
                    </tbody>
                </table>
                <?php echo csrf_field(); ?>
                <input type="hidden" name="klsId" value="">
            </form>
            <a href="<?php echo e(route('nilai.unduh-peserta', $kelasId)); ?>" class="btn btn-primary margin">Unduh Peserta Kelas</a>
            <table class="table table-condensed">
                <tr>
                    <th style="width: 10px">#</th>
                    <th>NIS</th>
                    <th>Nama</th>
                    <th>N. Raport Pengetahuan</th>
                    <th>Predikat Pengetahuan</th>
                    <th>N. Raport Ketrampilan</th>
                    <th>Predikat Ketrampilan</th>
                </tr>
                <?php $__currentLoopData = $peserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(++$key); ?></td>
                    <td><?php echo e($value->nis); ?></td>
                    <td><?php echo e($value->nama); ?></td>
                    <td><?php echo e($value->n_raport_pengetahuan ?? '-'); ?></td>
                    <td><?php echo e($value->predikat_pengetahuan ?? '-'); ?></td>
                    <td><?php echo e($value->n_raport_ketrampilan ?? '-'); ?></td>
                    <td><?php echo e($value->predikat_ketrampilan ?? '-'); ?></td>
                    
                    
                    
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <!-- /.box-body -->
    </div>
    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('script'); ?>
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/admin/kelas/peserta-kelas/index.blade.php ENDPATH**/ ?>