
<?php $__env->startSection('title'); ?>
<h1>
    Kelas
    <small>Control panel</small>
</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li class="active">Kelas</li>
</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="box">
    <div class="box-header">
        <h3 class="box-title">Daftar Kelas</h3>
        
        <!-- /.modal -->
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <table class="table table-condensed">
            <tr>
                <th style="width: 10px">#</th>
                <th>Tahun Semester</th>
                <th>NIS</th>
                <th>Nama</th>
                <th>Angkatan</th>
                <th>Jurusan</th>
                <th>Kelas</th>
                <th style="width: 250px">Pilihan</th>
            </tr>
            <?php $__currentLoopData = []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$key); ?></td>
                <td><?php echo e($value->nis); ?></td>
                <td><?php echo e($value->nama); ?></td>
                <td><?php echo e($value->user->email); ?></td>
                <td><?php echo e($value->jurusan->nama); ?></td>
                <td><?php echo e($value->angkatan); ?></td>
                <td><?php echo e($value->kelompok); ?></td>
                <td><i class="fa fa-<?php echo e($value->status_aktif == 1 ? 'check' : 'ban'); ?>"></i> <?php echo e($value->status_aktif == 1 ? 'Aktif' : 'Tidak Aktif'); ?></td>
                <td>
                    <button class="btn btn-sm bg-orange" data-toggle="modal" data-target="#modal-default-<?php echo $key; ?>"> <i class="fa fa-pencil"></i> Ubah</button>
                    <form action="<?php echo e(route('siswa.status', $value->id)); ?>" method="POST" style="display: inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <button class="btn btn-sm <?php echo e($value->status_aktif == 1 ? 'bg-black' : 'bg-green'); ?>" onclick="return confirm('Yakin ingin <?php echo e($value->status_aktif == 1 ? 'menonaktifkan' : 'mengaktifkan'); ?> siswa <?php echo e($value->nama); ?>?')"> <?php echo ($value->status_aktif == 1) ? 'Nonaktifkan!' : 'Aktifkan!'; ?></button>
                    </form>
                    <form action="<?php echo e(route('siswa.delete', $value->id)); ?>" method="POST" style="display: inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-sm bg-red" onclick="return confirm('Yakin ingin menghapus siswa <?php echo e($value->nama); ?>?')"> <i class="fa fa-trash"></i> Hapus</button>
                    </form>
                </td>
            </tr>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
    <!-- /.box-body -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/admin/kelas/index.blade.php ENDPATH**/ ?>