
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
<h1>
    Registrasi Siswa Semester
    <small>Control panel</small>
</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li class="active">Registrasi Siswa Semester</li>
</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="text-right margin">
    <form action="<?php echo e(route('kelas.register-siswa-semester')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <button type="submit"class="btn btn-primary">Registrasikan Siswa Semester Aktif</button>
    </form>
</div>
<div class="box">
    <div class="box-header">
        <h3 class="box-title">Daftar Siswa Teregistrasi Pada Semester Aktif</h3>
        <!-- /.modal -->
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <table id="table" class="table table-condensed">
            <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Tahun Semester</th>
                    <th>NIS</th>
                    <th>Nama</th>
                    <th>Angkatan</th>
                    <th>Jurusan</th>
                    <th>Kelas</th>
                    <th>Paket Semester</th>
                </tr>
            </thead>
            <?php $serviceKelas = app('App\Services\Kelas'); ?>
            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$key); ?></td>
                <td><?php echo e($value->nama_semester); ?></td>
                <td><?php echo e($value->nis); ?></td>
                <td><?php echo e($value->nama); ?></td>
                <td><?php echo e($value->angkatan); ?></td>
                <td><?php echo e($value->kode); ?></td>
                <td> <button class="btn btn-sm btn-primary">
                    <?php echo e($serviceKelas->kelasSemester($value->paket_semester,  $value->kelompok)); ?>

                </button></td>
                <td><?php echo e($value->paket_semester); ?></td>
                
            </tr>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
    <!-- /.box-body -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>

<script type="text/javascript">
    $('#table').DataTable({
        "pageLength": 50
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/admin/kelas/register-siswa/index.blade.php ENDPATH**/ ?>