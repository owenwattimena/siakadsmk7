
<?php $__env->startSection('breadcrump'); ?>
          <h1>
            Dashboard
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
            <li class="active">Kelas Peserta</li>
           
          </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
          
          <div class="row">
            <div class="col-xs-12">
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Setting Semester Aktif</h3>
                  
                </div><!-- /.box-header -->
                <div class="box-header">
                  <h3 class="box-title"><?php if( ! empty($kelaspeserta[0]['mkkurKode'])): ?> <?php echo e($kelaspeserta[0]['mkkurKode'].' - '.$kelaspeserta[0]['mkkurNama'].' - Kelas '.$kelaspeserta[0]['klsNama']); ?> <?php endif; ?></h3>
                </div>
                <div class="box-body flash-message">
                  <?php if(session('success')): ?> 
                  <div class="alert alert-info">
                    <strong><?php echo e(session('success')); ?></strong>
                  </div>
                  <?php elseif(session('error')): ?> 
                  <div class="alert alert-error">
                    <strong><?php echo e(session('error')); ?></strong>
                  </div>
                  <?php endif; ?>      
                </div>
                <div class="box-body">
                  <form action="<?php echo e(route('dashboard-guru.import-nilai', $kelasId)); ?>" class="form-horizontal" method="post" enctype="multipart/form-data">
                    <table class="table">
                    <tbody>  
                      <tr >
                        <td colspan="2" >
                        1. Gunakan Tombol "Download Peserta Kelas" untuk mendownload format file Upload.<br>
                        2. Upload file dalam ekstensi *.xlsx, *.xls, *.csv dan format sesuai dengan format file yang didownload.
                        </td>
                        
                      </tr>                     
                      <tr>
                        <td width="250px"><input class="btn " type="file" name="import_file" required accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"/></td>
                        <td align="left"><button class="btn btn-primary" type="submit">Import Nilai</button></td>     
                      </tr>                      
                    </tbody>
                    </table>
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <input type="hidden" name="klsId" value="<?php echo e($kelasId); ?>">
                  </form>
                  
                </div>
                <div class="box-body">
                  <p><strong>Download form nilai untuk peserta kelas matakuliah.</strong></p>
                  <div class="btn-group">
                        <a href="<?php echo e(route('dashboard-guru.peserta-download', $kelasId)); ?>"><button type="button" class="btn btn-flat btn-success">Download Peserta Kelas</button></a>
                        
                  </div>
                </div>
                <div class="box-body col-md-12" align="right" >  
                  <a href="<?php echo e(route('dashboard-guru.nilai-kelas', [$kelasId, 'cetak'=>false])); ?>" class="btn btn-flat btn-warning" value="Download Nilai Semester"><i class="fa fa-download"></i> Download</a>
                  <a href="<?php echo e(route('dashboard-guru.nilai-kelas', [$kelasId, 'cetak'=>true])); ?>" class="btn btn-flat btn-info" value="Cetak Nilai Semester"><i class="fa fa-print"></i> Cetak</a>
                </div>

                <div class="box-body">
                  <table id="dataKurikulum" class="table table-bordered table-hover">
                    <thead>
                      <tr>
                        <th>No.</th>          
                        <th>NIS</th>            
                        <th>Nama</th>                                                    
                        <th>Nilai Pengetahuan</th>
                        <th>Nilai Nilai Ketrampilan</th>
                        <th>Nilai Nilai Akhir</th>
                        <th>Nilai Bobot Nilai</th>
                        <th>Predikat</th>
                        
                      </tr>
                    </thead>
                    <tbody>
                     <?php if(! empty($peserta)): ?>
                     <?php $i=1;foreach ($peserta as $itemPeserta):  ?>
                      <tr>
                        <td><?php echo e($i); ?></td>
                        <td><?php echo e($itemPeserta->nis); ?></td>
                        <td><?php echo e($itemPeserta->nama); ?></td>
                        <td><?php echo e($itemPeserta->nilai_pengetahuan ?? '-'); ?></td>
                        <td><?php echo e($itemPeserta->nilai_ketrampilan ?? '-'); ?></td>
                        <td><?php echo e($itemPeserta->nilai_akhir ?? '-'); ?></td>
                        <td><?php echo e($itemPeserta->bobot_nilai ?? '-'); ?></td>
                        <td><?php echo e($itemPeserta->nilai_huruf ?? '-'); ?></td>
                      </tr>
                      <?php $i++; endforeach  ?>
                    <?php endif; ?>  
                    </tbody>
                    
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->

            </div><!-- /.col -->
          </div><!-- /.row -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/guru/peserta-kelas.blade.php ENDPATH**/ ?>