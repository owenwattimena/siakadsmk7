<?php echo $__env->make('admin.templates.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.templates.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-wrapper">
    <section class="content-header">
        <?php echo $__env->yieldContent('title'); ?>
        <?php echo $__env->yieldContent('breadcrumb'); ?>
        
    </section>
    <section class="content container-fluid">
        <?php if(session('status')): ?>
        <div class="alert alert-<?php echo session('status'); ?> alert-dismissible">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <?php
                $success = session('status') == 'danger' ? false : true;
            ?>
            <h4><i class="icon fa <?php echo e(!$success ? 'fa-ban' : 'fa-check'); ?>"></i> <?php echo e($success ? 'Berhasil' : 'Gagal'); ?> </h4>
            <?php echo session('message'); ?>

        </div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </section>
</div>
<?php echo $__env->make('admin.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.templates.right-side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.templates.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/admin/templates/template.blade.php ENDPATH**/ ?>