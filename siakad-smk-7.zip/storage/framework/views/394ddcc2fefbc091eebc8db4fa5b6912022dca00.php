<div class="alert bg-low-yellow p-0 mb-0" role="alert">
    <div class="container">
        <marquee behavior="" direction="" scrollamount="7" onmouseover="this.stop()" onmouseout="this.start()">
            <ul class="mb-0">
                <li>&bull;&nbsp;&nbsp;&nbsp;Ibadah AMGPM Menara Kasih Tanggal 29 April ditiadakan!</li>
                <li>&bull;&nbsp;&nbsp;&nbsp;Ibadah ranting dialihkan ke ibadah kunci bulan di gedung Gereja!</li>
            </ul>
        </marquee>
    </div>
</div>
<?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/web/templates/info.blade.php ENDPATH**/ ?>