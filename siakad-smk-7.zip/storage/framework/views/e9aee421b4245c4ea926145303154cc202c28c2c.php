
<?php $__env->startSection('title'); ?>
<h1>
    Saran & Masukan
    <small>Control panel</small>
</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li><i class="fa fa-dashboard"></i> Dashboard</li>
    <li class="active"><i class="fa fa-feed"></i> Saran & Masukan</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div>
    <div class="box">
        <div class="box-header">
            Saran & Masukan
        </div>
        <div class="box-body">
            <!-- Post -->
            <?php $__currentLoopData = $saran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
            <div class="post">
                <div class="user-block">
                    <img class="img-circle img-bordered-sm" src="https://ui-avatars.com/api/?name=<?php echo e($item->siswa->nama); ?>" alt="user image">
                    <span class="username">
                        <a href="#"><?php echo e($item->siswa->nama); ?></a>
                    </span>
                    
                    <span class="description"><?php echo e(Carbon\Carbon::createFromTimeString($item->created_at)->isoFormat('D MMMM Y')); ?></span>
                </div>
                <!-- /.user-block -->
                <h3><?php echo e($item->judul); ?></h3>
                <p>
                    <?php echo e($item->isi); ?>

                </p>
                
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/admin/saran/index.blade.php ENDPATH**/ ?>