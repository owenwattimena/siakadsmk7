
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
<h1>
    Semester Akademik <?php echo e($semester->nama_semester); ?>

    <small>Control panel</small>
</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li class="active">Semester Akademik <?php echo e($semester->nama_semester); ?></li>
</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="box">
    <div class="box-header">
        <h3 class="box-title">Daftar Semester Jurusan pada Semester Akademik <?php echo e($semester->nama_semester); ?></h3>
        <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#modal-default"><i class="fa fa-plus"></i> Tambah</button>
        <div class="modal fade" id="modal-default">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="<?php echo e(route('semester-jur.store', $semester->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <h4 class="modal-title">Tambah Semester Jurusan</h4>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="jurusan">Jurusan</label>
                                <select class="form-control" id="jurusan" name="jurusan_id">
                                    <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="tanggal_mulai_semester">Tanggal Mulai Pembelajaran</label>
                                <input type="date" class="form-control" id="tanggal_mulai_semester" name="tanggal_mulai_semester" placeholder="[Tanggal Mulai Pembelajaran]">
                            </div>
                            <div class="form-group">
                                <label for="tanggal_selesai_semester">Tanggal Selesai Pembelajaran</label>
                                <input type="date" class="form-control" id="tanggal_selesai_semester" name="tanggal_selesai_semester" placeholder="[Tanggal Selesai Pembelajaran]">
                            </div>
                            <div class="form-group">
                                <label for="tanggal_mulai_input_nilai">Mulai Input Nilai</label>
                                <input type="date" class="form-control" id="tanggal_mulai_input_nilai" name="tanggal_mulai_input_nilai" placeholder="[Mulai Input Nilai]">
                            </div>
                            <div class="form-group">
                                <label for="tanggal_selesai_input_nilai">Selesai Input Nilai</label>
                                <input type="date" class="form-control" id="tanggal_selesai_input_nilai" name="tanggal_selesai_input_nilai" placeholder="[Selesai Input Nilai]">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </div>
                </form>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <table id="table" class="table table-condensed">
            <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Jurusan</th>
                    <th>Tanggal Mulai Pembelajaran</th>
                    <th>Tanggal Selesai Pembelajaran</th>
                    <th>Mulai Input Nilai</th>
                    <th>Selesai Input Nilai</th>
                    <th>Status</th>
                    <th style="width: 210px">Pilihan</th>
                </tr>
            </thead>
            <?php $__currentLoopData = $semesterJurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$key); ?></td>
                <td><?php echo e($value->jurusan->nama); ?></td>
                <td><?php echo e($value->tanggal_mulai_semester); ?></td>
                <td><?php echo e($value->tanggal_selesai_semester); ?></td>
                <td><?php echo e($value->tanggal_mulai_input_nilai); ?></td>
                <td><?php echo e($value->tanggal_selesai_input_nilai); ?></td>
                <td><i class="fa fa-<?php echo e($value->status_aktif == 1 ? 'check' : 'ban'); ?>"></i> <?php echo e($value->status_aktif == 1 ? 'Aktif' : 'Tidak Aktif'); ?></td>
                <td>
                    <button class="btn btn-sm btn-warning" data-toggle="modal" data-target="#modal-edit"><i class="fa fa-pencil"></i> Ubah</button>
                    <form action="<?php echo e(route('semester-jur.status', [$semester->id ,$value->id])); ?>" method="POST" style="display: inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <button class="btn btn-sm <?php echo e($value->status_aktif == 1 ? 'bg-black' : 'bg-green'); ?>" onclick="return confirm('Yakin ingin <?php echo e($value->status_aktif == 1 ? 'menonaktifkan' : 'mengaktifkan'); ?> semester <?php echo e($value->jurusan->nama); ?>?')"> <?php echo ($value->status_aktif == 1) ? 'Nonaktifkan!' : 'Aktifkan!'; ?></button>
                    </form>
                    <form action="<?php echo e(route('semester-jur.delete', [$semester->id ,$value->id])); ?>" method="POST" style="display: inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-sm bg-red" onclick="return confirm('Yakin ingin menghapus semester <?php echo e($value->nama_semester); ?>?')"> <i class="fa fa-trash"></i> Hapus</button>
                    </form>
                </td>
            </tr>
            <div class="modal fade" id="modal-edit">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form action="<?php echo e(route('semester-jur.update', $semester->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="semester_jurusan_id" value="<?php echo e($value->id); ?>">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <h4 class="modal-title">Ubah Semester Jurusan</h4>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="jurusan">Jurusan</label>
                                    <select class="form-control" id="jurusan" name="jurusan_id" disabled>
                                        <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e($value->jurusan_id == $item->id ? "selected" : ""); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="tanggal_mulai_semester">Tanggal Mulai Pembelajaran</label>
                                    <input type="date" value="<?php echo e($value->tanggal_mulai_semester); ?>" class="form-control" id="tanggal_mulai_semester" name="tanggal_mulai_semester" placeholder="[Tanggal Mulai Pembelajaran]">
                                </div>
                                <div class="form-group">
                                    <label for="tanggal_selesai_semester">Tanggal Selesai Pembelajaran</label>
                                    <input type="date" value="<?php echo e($value->tanggal_selesai_semester); ?>" class="form-control" id="tanggal_selesai_semester" name="tanggal_selesai_semester" placeholder="[Tanggal Selesai Pembelajaran]">
                                </div>
                                <div class="form-group">
                                    <label for="tanggal_mulai_input_nilai">Mulai Input Nilai</label>
                                    <input type="date" value="<?php echo e($value->tanggal_mulai_input_nilai); ?>" class="form-control" id="tanggal_mulai_input_nilai" name="tanggal_mulai_input_nilai" placeholder="[Mulai Input Nilai]">
                                </div>
                                <div class="form-group">
                                    <label for="tanggal_selesai_input_nilai">Selesai Input Nilai</label>
                                    <input type="date" value="<?php echo e($value->tanggal_selesai_semester); ?>" class="form-control" id="tanggal_selesai_input_nilai" name="tanggal_selesai_input_nilai" placeholder="[Selesai Input Nilai]">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-primary">Simpan</button>
                            </div>
                        </div>
                    </form>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
    <!-- /.box-body -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">
    $('#table').DataTable({
        "pageLength": 50
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/admin/semester-jurusan/index.blade.php ENDPATH**/ ?>