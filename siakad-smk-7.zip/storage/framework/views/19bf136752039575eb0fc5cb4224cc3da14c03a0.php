
<?php $__env->startSection('title'); ?>
<h1>
    Dashboard Guru
    <small>Control panel</small>
</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li class="active"><i class="fa fa-dashboard"></i> Dashboard</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div>
    <div class="callout callout-info">
        <h4>Selamat Datang <?php echo e(Auth::user()->name); ?></h4>
        
        <p></p>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/guru/dashboard.blade.php ENDPATH**/ ?>