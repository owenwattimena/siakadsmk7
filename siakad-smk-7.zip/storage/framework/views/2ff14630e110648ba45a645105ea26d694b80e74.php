
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
<h1>
    Jurusan
    <small>Control panel</small>
</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li class="active">Jurusan</li>
</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="box">
    <div class="box-header">
        <h3 class="box-title">Daftar Jurusan</h3>
        
        <div class="modal fade" id="modal-default">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="<?php echo e(route('jurusan.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <h4 class="modal-title">Tambah Jurusan</h4>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="nama">Nama Jurusan</label>
                                <input type="text" class="form-control" id="nama" name="nama" placeholder="[Nama Jurusan]">
                            </div>
                            <div class="form-group">
                                <label for="kode">Kode Jurusan</label>
                                <input type="text" class="form-control" id="kode" name="kode" placeholder="[Kode Jurusan]">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </div>
                </form>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <table class="table table-condensed" id="table">
            <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Jurusan</th>
                    <th>Kode Jurusan</th>
                    <th style="width: 150px">Pilihan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(++$key); ?></td>
                    <td>[<?php echo e($value->id); ?>]<?php echo e($value->nama); ?></td>
                    <td><?php echo e($value->kode); ?></td>
                    <td>
                        <button class="btn btn-sm bg-orange" data-toggle="modal" data-target="#modal-default-<?php echo $key; ?>"> <i class="fa fa-pencil"></i> Ubah</button>
                        <?php if(count($value->kurikulum) <= 0): ?>
                        <form action="<?php echo e(route('jurusan.delete', $value->id)); ?>" method="POST" style="display: inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="btn btn-sm bg-red" onclick="return confirm('Yakin ingin menghapus jurusan <?php echo e($value->kode); ?>?')"> <i class="fa fa-trash"></i> Hapus</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <div class="modal fade" id="modal-default-<?php echo $key; ?>">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="<?php echo e(route('jurusan.update', $value->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <h4 class="modal-title">Ubah Jurusan</h4>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label for="nama">Nama Jurusan</label>
                                        <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e($value->nama); ?>" placeholder="[Nama Jurusan]">
                                    </div>
                                    <div class="form-group">
                                        <label for="kode">Kode Jurusan</label>
                                        <input type="text" class="form-control" id="kode" name="kode" value="<?php echo e($value->kode); ?>" placeholder="[Kode Jurusan]">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Batal</button>
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </div>
                            </div>
                        </form>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <!-- /.box-body -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script>
    $('#table').DataTable()
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/admin/jurusan/main.blade.php ENDPATH**/ ?>