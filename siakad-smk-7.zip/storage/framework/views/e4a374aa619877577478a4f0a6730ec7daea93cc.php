
<?php $__env->startSection('title'); ?>
<h1>
    Registrasi Kelas Semester
    <small>Control panel</small>
</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li class="active">Registrasi Siswa Semester</li>
</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="margin padding">
    <div class="box">
        <div class="box-header">
            <h3 class="box-title">Daftar Kelas Teregistrasi Pada Semester Aktif</h3>
            <!-- /.modal -->
        </div>
        <!-- /.box-header -->
        <div class="box-body">
            <?php $serviceKelas = app('App\Services\Kelas'); ?>
            <h3><?php echo e($peserta->first()->mapel_kuri_id); ?>-<?php echo e($peserta->first()->mapel); ?> | Kelas <?php echo e($serviceKelas->kelasSemester($peserta->first()->paket_semester,$peserta->first()->nama_kelas)); ?> </h3>
            
            <table class="table table-condensed">
                <tr>
                    <th style="width: 10px">#</th>
                    <th>NIS</th>
                    <th>Nama</th>
                    <th>N. Raport Pengetahuan</th>
                    <th>Predikat Pengetahuan</th>
                    <th>N. Raport Ketrampilan</th>
                    <th>Predikat Ketrampilan</th>
                    
                </tr>
                <?php $__currentLoopData = $peserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(++$key); ?></td>
                    <td><?php echo e($value->nis); ?></td>
                    <td><?php echo e($value->nama); ?></td>
                    <td><?php echo e($value->n_raport_pengetahuan ?? '-'); ?></td>
                    <td><?php echo e($value->predikat_pengetahuan ?? '-'); ?></td>
                    <td><?php echo e($value->n_raport_ketrampilan ?? '-'); ?></td>
                    <td><?php echo e($value->predikat_ketrampilan ?? '-'); ?></td>
                    
                    
                    
                    
                    
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <!-- /.box-body -->
    </div>
    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('script'); ?>
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/admin/kelas/peserta-kelas/index1.blade.php ENDPATH**/ ?>