
<?php $__env->startSection('style'); ?>
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
<h1>
    Registrasi Kelas Semester
    <small>Control panel</small>
</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li class="active">Registrasi Siswa Semester</li>
</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="margin padding">
    <form action="<?php echo e(route('kelas.register-kelas-semester-aktif')); ?>" method="post" class="form-horizontal">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="jurusan_kode" class="col-sm-6 control-label">Pilih Jurusan</label>
            <div class="col-sm-3">
                <select name="jurusan_kode" id="jurusan_kode" class="form-control">
                    <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e(isset($jurusanKode) ? ($jurusanKode == $item->kode ? 'selected' : '' ) : ''); ?> value="<?php echo e($item->kode); ?>"><?php echo e($item->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-sm-3">
                <button type="submit"class="btn btn-primary">Registrasikan Kelas Semester Aktif</button>
            </div>
        </div>
    </form>
</div>
<div class="box">
    <div class="box-header">
        <h3 class="box-title">Daftar Kelas Teregistrasi Pada Semester Aktif</h3>
        <!-- /.modal -->
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <table id="table" class="table table-condensed">
            <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Tahun Semester</th>
                    <th>Semester</th>
                    <th>Nama Mata Pelajaran</th>
                    <th>SKM</th>
                    <th>No Guru</th>
                    <th>Nama Guru</th>
                    <th>Kelas</th>
                    <th>Pilihan</th>
                </tr>
            </thead>
            <?php $serviceKelas = app('App\Services\Kelas'); ?>
            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$key); ?></td>
                <td><?php echo e($value->nama_semester); ?></td>
                <td><?php echo e($value->mapel_semester); ?></td>
                <td><?php echo e($value->mapel); ?></td>
                <td><?php echo e($value->mapel_skm); ?></td>
                <td><?php echo e($value->nign); ?></td>
                <td>
                    <?php if(isset($value->nama_guru)): ?> 
                    <button class="btn btn-primary btn-flat btn-sm" onclick="return showModal(`<?php echo e($value->mapel); ?>`, `<?php echo e($value->mapel_semester); ?>`, `<?php echo e($value->kelas_id); ?>`)" title="Ubah">
                        <?php echo e($value->nama_guru); ?> 
                    </button>
                    <?php else: ?> 
                    <a class="btn btn-warning btn-flat btn-sm" onclick="return showModal(`<?php echo e($value->mapel); ?>`, `<?php echo e($value->mapel_semester); ?>`, `<?php echo e($value->kelas_id); ?>`)" title="Register"><i class="fa fa-plus"></i></a> 
                    <?php endif; ?>
                </td>
                <td> <span class="label bg-blue"><?php echo e($serviceKelas->kelasSemester($value->mapel_semester, $value->kelas_nama)); ?></span></td>
                
                <td> <a href="<?php echo e(route('kelas.peserta', $value->kelas_id)); ?>" class="btn btn-sm bg-black"> <i class="fa fa-list"></i> Peserta</a></td>
                
                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
    <!-- /.box-body -->
    <div class="modal fade" id="modal-dosen">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Pilih Guru</h4>
                        <div class="box-header label label-info">
                            <h3 class="box-title">Matapelajaran - <span id="textMatapelajaran"></span> (Semester : <span id="textSemester"></span>)</h3>
                        </div> 
                    </div>
                    <form action="<?php echo e(route('kelas.add-guru-mapel')); ?>" method="POST" id="formTambahDosen">
                        <input type="hidden" name="id_kelas" id="idKelas">
                        <div class="modal-body">
                            <table id="table-guru" class="table">
                                <thead>
                                    <tr>
                                        <th>No Guru</th>
                                        <th>Nama Guru</th>
                                        <th>Pilih</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(isset($guru)): ?>
                                    <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemGuru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($itemGuru->nign); ?></td>
                                        <td><?php echo e($itemGuru->nama); ?></td>
                                        <td>
                                            <input type="radio" name="id_guru" value="<?php echo e($itemGuru->id); ?>">
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
    </div>
    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('script'); ?>
    
    <script src="<?php echo e(asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>


    <script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.7/dist/loadingoverlay.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script>
        $('#table').DataTable({
            "pageLength": 50
        });
        $('#table-guru').DataTable({
            "pageLength": 50
        })
        function showModal(matapelajaran, semester, idKelas){
            $('input[type="radio"]')[0].checked = false;
            $('#textMatapelajaran').text(`${matapelajaran}`);
            $('#textSemester').text(`${semester}`);
            $('#idKelas').val(`${idKelas}`);
            $("#modal-dosen").modal('show');
            return false;
        }

        $(document).on('submit', '#formTambahDosen',function(e){
            $.LoadingOverlay("show");
            e.preventDefault();
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                method : $(this).attr('method'),
                url : $(this).attr('action'),
                data : $(this).serialize(),
                dataType : 'json',
            })
            .done(function(data){
                $.LoadingOverlay("hide");
                location.reload();
            })
            .fail(function(data){
                $.LoadingOverlay("hide");
                let json = data.responseJSON;
                var data = json.data;
                if(typeof data.id_guru != undefined){
                    data.id_guru.forEach(element => {
                        toastr.error(element)
                    });
                }
            });
        })
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/admin/kelas/register-kelas/index.blade.php ENDPATH**/ ?>