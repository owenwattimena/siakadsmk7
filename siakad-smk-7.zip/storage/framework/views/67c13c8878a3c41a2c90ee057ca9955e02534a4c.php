<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <!-- Sidebar user panel (optional) -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="http://siakad-smk-7.dev.test/assets/images/logo-smk-7.png" class="img-circle"
                    alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php echo e(\Auth::user()->name); ?></p>
                <!-- Status -->
                <a href="#"><i class="fa fa-circle text-success"></i> <?php echo e(\Auth::user()->email); ?></a>
            </div>
        </div>

        <!-- search form (Optional) -->
        
        <!-- /.search form -->

        <!-- Sidebar Menu -->
        <ul class="sidebar-menu" data-widget="tree">
            
            <!-- Optionally, you can add icons to the links -->
            <?php if(\Auth::user()->level_id == 1 ||  \Auth::user()->level_id == 2): ?>
            <li class="<?php echo e((request()->is('dashboard*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
            <li class="<?php echo e((request()->is('visi-misi*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('visi.misi')); ?>"><i class="fa fa-list"></i> <span>Visi & Misi</span></a></li>
            <li class="<?php echo e((request()->is('galeri*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('galeri')); ?>"><i class="fa fa-photo"></i> <span>Galeri</span></a></li>
            <li class="<?php echo e((request()->is('jurusan*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('jurusan.main')); ?>"><i class="fa fa-building"></i> <span>Jurusan</span></a></li>
            <li class="<?php echo e((request()->is('kurikulum*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('kurikulum.main')); ?>"><i class="fa fa-book"></i> <span>Kurikulum</span></a></li>
            <li class="<?php echo e((request()->is('semester*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('semester.main')); ?>"><i class="fa fa-calendar"></i> <span>Semester Akademik</span></a></li>
            <li class="<?php echo e((request()->is('guru*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('guru.main')); ?>"><i class="fa fa-user"></i> <span>Guru</span></a></li>
            <li class="<?php echo e((request()->is('siswa*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('siswa.main')); ?>"><i class="fa fa-users"></i> <span>Siswa</span></a></li>
            <li class="treeview <?php echo e((request()->is('kelas*')) ? 'active' : ''); ?>">
                <a href="#"><i class="fa fa-list"></i> <span>Kelas</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo e((request()->is('kelas/register-siswa*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('kelas.register-siswa')); ?>"><i class="fa fa-circle-o"></i> <span>Register Siswa</span></a></li>
                    <li class="<?php echo e((request()->is('kelas/register-kelas*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('kelas.register-kelas')); ?>"><i class="fa fa-circle-o"></i> <span>Register Kelas Mapel</span></a></li>
                </ul>
            </li>
            <li class="treeview <?php echo e((request()->is('nilai*')) ? 'active' : ''); ?>">
                <a href="#"><i class="fa fa-star"></i> <span>Hasil Studi</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo e((request()->is('nilai/input-nilai*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('nilai.input-nilai')); ?>"><i class="fa fa-circle-o"></i> <span>Input Nilai</span></a></li>
                </ul>
            </li>
            <li class="<?php echo e((request()->is('saran*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('saran')); ?>"><i class="fa fa-feed"></i> <span>Saran & Masukan</span></a></li>
            <?php elseif(\Auth::user()->level_id == 3): ?>   
            <li class="<?php echo e((request()->is('dashboard-guru')) ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard-guru')); ?>"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
            <li class="<?php echo e((request()->is('visi-misi*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('visi.misi')); ?>"><i class="fa fa-list"></i> <span>Visi & Misi</span></a></li>
            <li class="<?php echo e((request()->is('galeri*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('galeri')); ?>"><i class="fa fa-photo"></i> <span>Galeri</span></a></li>
            <li class="<?php echo e((request()->is('dashboard-guru/kelas*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard-guru.kelas')); ?>"><i class="fa fa-list"></i> <span>Kelas</span></a></li>
            <?php elseif(\Auth::user()->level_id == 4): ?>   
            <li class="<?php echo e((request()->is('dashboard-siswa')) ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard-siswa')); ?>"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
            <li class="<?php echo e((request()->is('visi-misi*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('visi.misi')); ?>"><i class="fa fa-list"></i> <span>Visi & Misi</span></a></li>
            <li class="<?php echo e((request()->is('galeri*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('galeri')); ?>"><i class="fa fa-photo"></i> <span>Galeri</span></a></li>
            <li class="<?php echo e((request()->is('dashboard-siswa/tugas*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard-siswa.tugas')); ?>"><i class="fa fa-book"></i> <span>Tugas</span></a></li>
            <li class="<?php echo e((request()->is('dashboard-siswa/nilai*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard-siswa.nilai')); ?>"><i class="fa fa-star"></i> <span>Nilai</span></a></li>
            <li class="<?php echo e((request()->is('dashboard-siswa/saran*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard-siswa.saran')); ?>"><i class="fa fa-feed"></i> <span>Saran & Masukan</span></a></li>
            <?php endif; ?>
        </ul>
        <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>
<?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/admin/templates/aside.blade.php ENDPATH**/ ?>