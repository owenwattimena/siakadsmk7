
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
<h1>
    Daftar Kelas
    <small>Control panel</small>
</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li class="active">Daftar Kelas</li>
</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="margin padding">
    <form action="<?php echo e(route('dashboard-guru.kelas')); ?>" method="post" class="form-horizontal">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="semester_id" class="col-sm-6 control-label">Tahun Akademik</label>
            <div class="col-sm-3">
                <select name="semester_id" id="semester_id" class="form-control">
                    <?php $__currentLoopData = $semesterGuru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->semester_id); ?>"><?php echo e($item->tahun_pelajaran); ?> - <?php echo e($item->jenis_semester % 2 == 0 ? 'Genap' : 'Ganjil'); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-sm-3">
                <button type="submit"class="btn btn-primary">Pilih</button>
            </div>
        </div>
    </form>
</div>
<div class="box">
    <div class="box-header">
        <h3 class="box-title">Daftar Kelas</h3>
        <!-- /.modal -->
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <table class="table table-condensed">
            <tr>
                <th style="width: 10px">#</th>
                <th>Nama Mata Pelajaran</th>
                <th>SKM</th>
                <th>Semester</th>
                <th>Kelas</th>
                <th>Pilihan</th>
            </tr>
            <?php if(isset($ampuSemester)): ?>
            <?php $serviceKelas = app('App\Services\Kelas'); ?>
            <?php $__currentLoopData = $ampuSemester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$key); ?></td>
                <td><?php echo e($value->mapel); ?></td>
                <td><?php echo e($value->skm); ?></td>
                <td><?php echo e($value->semester); ?></td>
                <td> <span class="label bg-blue"><?php echo e($serviceKelas->kelasSemester($value->semester,$value->nama_kelas)); ?></span></td>
                <td> 
                    <a href="<?php echo e(route('dashboard-guru.peserta', $value->kelas_id)); ?>" class="btn btn-sm bg-black"> <i class="fa fa-list"></i> Peserta</a>
                    <a href="<?php echo e(route('dashboard-guru.kelas-tugas', $value->kelas_id)); ?>" class="btn btn-sm bg-red"> <i class="fa fa-book"></i> Tugas</a>
                    <a href="<?php echo e(route('dashboard-guru.kelas-pengumuman', $value->kelas_id)); ?>" class="btn btn-sm bg-yellow"> <i class="fa fa-bullhorn"></i> Pengumuman</a></td>
                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            
        </table>
    </div>
    <!-- /.box-body -->
    <div class="modal fade" id="modal-dosen">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Pilih Guru</h4>
                        <div class="box-header label label-info">
                            <h3 class="box-title">Matapelajaran - <span id="textMatapelajaran"></span> (Semester : <span id="textSemester"></span>)</h3>
                        </div> 
                    </div>
                    <form action="<?php echo e(route('kelas.add-guru-mapel')); ?>" method="POST" id="formTambahDosen">
                        <input type="hidden" name="id_kelas" id="idKelas">
                        <div class="modal-body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>No Guru</th>
                                        <th>Nama Guru</th>
                                        <th>Pilih</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(isset($guru)): ?>
                                    <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemGuru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($itemGuru->nign); ?></td>
                                        <td><?php echo e($itemGuru->nama); ?></td>
                                        <td>
                                            <input type="radio" name="id_guru" value="<?php echo e($itemGuru->id); ?>">
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
    </div>
    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('script'); ?>
    <script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.7/dist/loadingoverlay.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script>
        function showModal(matapelajaran, semester, idKelas){
            $('input[type="radio"]')[0].checked = false;
            $('#textMatapelajaran').text(`${matapelajaran}`);
            $('#textSemester').text(`${semester}`);
            $('#idKelas').val(`${idKelas}`);
            $("#modal-dosen").modal('show');
            return false;
        }

        $(document).on('submit', '#formTambahDosen',function(e){
            $.LoadingOverlay("show");
            e.preventDefault();
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                method : $(this).attr('method'),
                url : $(this).attr('action'),
                data : $(this).serialize(),
                dataType : 'json',
            })
            .done(function(data){
                $.LoadingOverlay("hide");
                location.reload();
            })
            .fail(function(data){
                $.LoadingOverlay("hide");
                let json = data.responseJSON;
                var data = json.data;
                if(typeof data.id_guru != undefined){
                    data.id_guru.forEach(element => {
                        toastr.error(element)
                    });
                }
            });
        })
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/guru/daftar-kelas.blade.php ENDPATH**/ ?>