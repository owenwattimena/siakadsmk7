<html>
<head>
    <title>Cetak Nilai</title>
</head>
<body>
    <style type="text/css">
        table {
            width: 100%;
        }

        table,
        th,
        td {
            /* border: 1px solid black; */

        }

        th,
        td {
            padding: 5px;
            text-align: left;
            vertical-align: middle;
            border-bottom: 1px solid #ddd;
            font-size: 12px;
        }

        th {
            border-top: 1px solid #ddd;
            height: 20px;
            background-color: #ddd;
            text-align: center;
        }

        .noborder th,
        .noborder td {
            border: 0;
        }

    </style>
    <center>
        <font size="15">HASIL BELAJAR SISWA<br>
            SMK NEGERI 7 AMBON<br>
            TAHUN AKADEMIK <?php echo e($semester->tahun_pelajaran); ?> <?php echo e($semester->jenis_semester % 2 == 0 ? 'GENAP' : 'GANJIL'); ?></font>
        <br>
        <hr>
        <br>
    </center>

    <?php if(isset($siswa)): ?>
    <table class="noborder">
        <tbody>
            <tr>
                <td><b>NIS</b></td>
                <td><span class="badge bg-white">: <b> <?php echo e($siswa->nis); ?> </span></b></td>
            </tr>
            <tr>
                <td><b>NAMA</b></td>
                <td><span class="badge bg-light-white">: <b> <?php echo e($siswa->nama); ?> </b></span></td>
            </tr>
        </tbody>
    </table>
    <?php endif; ?>
    <br>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th width="65%">Matapelajaran</th>
                <th>N. Raport Pengetahuan</th>
                <th>Predikat Pengetahuan</th>
                <th>N. Raport Ketrampilan</th>
                <th>Predikat Ketrampilan</th>
            </tr>
        </thead>
        <tbody>
            <?php if(! empty($nilai)): ?>
            <?php $i=1;foreach ($nilai as $value):  ?>
            <tr>
                <td><?php echo e($i); ?></td>
                <td><?php echo e($value->nama); ?></td>
                <td><?php echo e($value->n_raport_pengetahuan ?? '-'); ?></td>
                <td><?php echo e($value->predikat_pengetahuan ?? '-'); ?></td>
                <td><?php echo e($value->n_raport_ketrampilan ?? '-'); ?></td>
                <td><?php echo e($value->predikat_ketrampilan ?? '-'); ?></td>
            </tr>
            <?php $i++; endforeach  ?>
            <?php endif; ?>
        </tbody>
    </table>
    <br>
    <table class="noborder">
        <tr>
            <td width="70%" align="center"></td>
            <td align="left">Ambon, <?php echo e($today); ?></td>
        </tr>
        <tr height="60px">
            <td width="70%" align="center"></td>
            <td></td>
        </tr>
        <tr>
            <td width="70%" align="center"></td>
            <td align="left"><br><br><br>_________________________</td>
        </tr>
    </table>
</body>
</html>
<?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/siswa/cetak-nilai.blade.php ENDPATH**/ ?>