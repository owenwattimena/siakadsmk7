

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
<h1>
    Tugas Kelas
    <?php $serviceKelas = app('App\Services\Kelas'); ?>
    <small><?php echo e($kelas->nama_mapel); ?> <?php echo e($serviceKelas->kelasSemester($kelas->semester, $kelas->nama)); ?></small>
</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li class="active"><i class="fa fa-dashboard"></i> Dashboard</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div>
    <div class="box">
        <div class="box-header">
            Daftar Tugas
            <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modal-default">Tambah</button>
            <div class="modal fade" id="modal-default">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form action="<?php echo e(route('dashboard-guru.kelas-tugas.create', $kelasId)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <h4 class="modal-title">Tambah Tugas</h4>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="judul">Judul</label>
                                    <input type="text" class="form-control" id="judul" name="judul" placeholder="[Judul Tugas]">
                                </div>
                                <div class="form-group">
                                    <label for="keterangan">Keterangan</label>
                                    <input type="text" class="form-control" id="keterangan" name="keterangan" placeholder="[Keterangan Tugas]">
                                </div>
                                <div class="form-group">
                                    <label for="file">File</label>
                                    <input type="file" class="form-control" id="file" name="file" placeholder="[File]">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-primary">Simpan</button>
                            </div>
                    </div>
                    </form>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
            </div>
        </div>
        <div class="box-body">
            <div class="table-responsive">
                <table id="table" class="table">
                    <thead>
                        <tr>
                            <th style="width: 10px">#</th>
                            <th>Tugas</th>
                            <th>Keterangan</th>
                            <th>File</th>
                            <th>Pilihan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $file = explode('/', $item->file);
                        $file = 'storage/tugas/'.end($file);
                        ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($item->judul); ?></td>
                            <td><?php echo e($item->keterangan); ?></td>
                            <td><a href="<?php echo e(asset($file)); ?>" target="_blank">Link File</a></td>
                            <td>
                                <button class="btn btn-sm btn-warning" data-toggle="modal" data-target="#modal-default-<?php echo $key; ?>"><i class="fa fa-pencil"></i> Ubah</button>
                                <a href="<?php echo e(route('dashboard-guru.kelas-tugas.detail', [$kelasId, $item->id])); ?>" class="btn btn-sm btn-primary"><i class="fa fa-eye"></i> Detail</a>
                                <form action="<?php echo e(route('dashboard-guru.kelas-tugas.delete', [$kelasId, $item->id])); ?>" method="post" style="display: inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger btn-sm" onclick="confirm('Yakin ingin menghapus Tugas?')"><i class="fa fa-trash"></i> Hapus</button>
                                </form>
                            </td>
                        </tr>
                        <div class="modal fade" id="modal-default-<?php echo $key; ?>">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form action="<?php echo e(route('dashboard-guru.kelas-tugas.update', $kelasId)); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('put'); ?>
                                        <input type="hidden" name="id_tugas" value="<?php echo e($item->id); ?>">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                            <h4 class="modal-title">Ubah Tugas</h4>
                                        </div>
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label for="judul">Judul</label>
                                                <input type="text" class="form-control" id="judul" name="judul" value="<?php echo e($item->judul); ?>" placeholder="[Judul Tugas]">
                                            </div>
                                            <div class="form-group">
                                                <label for="keterangan">Keterangan</label>
                                                <input type="text" class="form-control" id="keterangan" name="keterangan" value="<?php echo e($item->keterangan); ?>" placeholder="[Keterangan Tugas]">
                                            </div>
                                            <div class="form-group">
                                                <label for="file">File</label>
                                                <input type="file" class="form-control" id="file" name="file" placeholder="[File]">
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Batal</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                    </div>
                                </form>
                                <!-- /.modal-content -->
                            </div>
                            <!-- /.modal-dialog -->
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">
    $('#table').DataTable({
        "pageLength": 50
    })

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/guru/tugas.blade.php ENDPATH**/ ?>