
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">

<?php $__env->startSection('title'); ?>
<h1>
    Visi Misi
    <small></small>
</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li class="active"><i class="fa fa-dashboard"></i> Visi Misi</li>
</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="nav-tabs-custom">
    <ul class="nav nav-tabs">
        <li class="active"><a href="#tab_1" data-toggle="tab">VISI</a></li>
        <li><a href="#tab_2" data-toggle="tab">MISI</a></li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane active" id="tab_1">
            <?php if(auth()->user()->level_id ==1 || auth()->user()->level_id ==2): ?>
            <form action="<?php echo e(route('visi.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <button class="btn btn-primary margin">SIMPAN</button>
                <textarea class="textarea" name="visi" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo $pengaturan->visi ?? ''; ?></textarea>
            </form>
            <?php else: ?>
            <?php echo $pengaturan->visi; ?>

            <?php endif; ?>
        </div>

        <div class="tab-pane" id="tab_2">
            <?php if(auth()->user()->level_id ==1 || auth()->user()->level_id ==2): ?>
            <form action="<?php echo e(route('misi.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <button class="btn btn-primary margin">SIMPAN</button>
                <textarea class="textarea" name="misi" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo $pengaturan->misi ?? ''; ?></textarea>
            </form>
            <?php else: ?>
            <?php echo $pengaturan->misi ?? ''; ?>

            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets')); ?>/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<script>
  $(function () {
    $('.textarea').wysihtml5()
  })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/admin/visi-misi/index.blade.php ENDPATH**/ ?>