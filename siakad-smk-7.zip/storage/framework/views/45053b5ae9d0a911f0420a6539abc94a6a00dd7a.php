
<?php $__env->startSection('title'); ?>
<h1>
    Tugas
    
</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li class="active"><i class="fa fa-dashboard"></i> Dashboard</li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div>
    <div class="box">
        <div class="box-header">
            Tugas
        </div>
        <div class="box-body">
            <div class="table-responsive">
                <table id="table" class="table">
                    <thead>
                        <tr>
                            <td>#</td>
                            <td>MATA PELAJARAN</td>
                            <td>GURU</td>
                            <td>JUDUL</td>
                            <td>KETERANGAN</td>
                            <td>FILE</td>
                            <td>STATUS</td>
                            <td>PILIHAN</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $file = explode('/', $item->file);
                        $file = 'storage/tugas/'.end($file);
                        ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($item->mapel); ?></td>
                            <td><?php echo e($item->guru); ?></td>
                            <td><?php echo e($item->judul); ?></td>
                            <td><?php echo e($item->keterangan); ?></td>
                            <td><a href="<?php echo e(asset($file)); ?>">Link File</a></td>
                            <td><?php echo $item->status <= 0 ? '<span class="badge bg-red">Belum Di kerjakan</span>' : '<span class="badge bg-green">Sudah Di kerjakan</span>'; ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#modal-default-<?php echo $key; ?>"><i class="fa fa-upload"></i> Unggah</button>
                            </td>
                        </tr>
                        <div class="modal fade" id="modal-default-<?php echo $key; ?>">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form action="<?php echo e(route('dashboard-siswa.tugas-unggah')); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('post'); ?>
                                        <input type="hidden" name="id_tugas" value="<?php echo e($item->id); ?>">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                            <h4 class="modal-title">Unggah Tugas</h4>
                                        </div>
                                        <div class="modal-body">
                                            <div class="form-group">
                                                <label for="keterangan">Keterangan</label>
                                                <input type="text" class="form-control" id="keterangan" name="keterangan" placeholder="[Keterangan Tugas]">
                                            </div>
                                            <div class="form-group">
                                                <label for="file">File</label>
                                                <input type="file" class="form-control" id="file" name="file" placeholder="[File]">
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Batal</button>
                                            <button type="submit" class="btn btn-primary">Simpan</button>
                                        </div>
                                    </div>
                                </form>
                                <!-- /.modal-content -->
                            </div>
                            <!-- /.modal-dialog -->
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/siswa/tugas.blade.php ENDPATH**/ ?>