
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
<h1>
    Siswa
    <small>Control panel</small>
</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li class="active">Siswa</li>
</ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="box">
    <div class="box-header">
        <h3 class="box-title">Daftar Siswa</h3>
        <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#modal-default"><i class="fa fa-plus"></i> Tambah</button>
        <div class="modal fade" id="modal-default">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="<?php echo e(route('siswa.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <h4 class="modal-title">Tambah Siswa</h4>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="jurusan">Jurusan</label>
                                <select class="form-control" id="jurusan" name="jurusan_kode">
                                    <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->kode); ?>"><?php echo e($item->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="nis">NIS</label>
                                <input type="number" class="form-control" id="nis" name="nis" placeholder="[Nomor Induk Siswa]">
                            </div>
                            <div class="form-group">
                                <label for="nama">Nama</label>
                                <input type="text" class="form-control" id="nama" name="nama" placeholder="[Nama Siswa]">
                            </div>
                            <div class="form-group">
                                <label for="angkatan">Angkatan</label>
                                <input type="number" min="2010" max="2110" class="form-control" id="angkatan" name="angkatan" placeholder="[Angkatan]">
                            </div>
                            <div class="form-group">
                                <label for="kelompok">Kelas</label>
                                <input type="text" class="form-control" id="kelompok" name="kelompok" placeholder="[Kelompok]">
                            </div>
                            <div class="form-group">
                                <label for="kurikulum_id">Kurikulum Yang Diikuti</label>
                                <select class="form-control" id="kurikulum_id" name="kurikulum_id">
                                    <?php $__currentLoopData = $kurikulum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemKurikulum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($itemKurikulum->id); ?>"><?php echo e($itemKurikulum->nama); ?> - <?php echo e($itemKurikulum->jurusan_kode); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="[Email]">
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </div>
                </form>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->
    </div>
    <!-- /.box-header -->
    <div class="box-body">
        <table id="table" class="table table-condensed">
            <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>NIS</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Jurusan</th>
                    <th>Angkatan</th>
                    <th>Kelas</th>
                    <th>Status</th>
                    <th style="width: 250px">Pilihan</th>
                </tr>
            </thead>
            <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$key); ?></td>
                <td><?php echo e($value->nis); ?></td>
                <td><?php echo e($value->nama); ?></td>
                <td><?php echo e($value->user->email); ?></td>
                <td><?php echo e($value->jurusan->nama); ?></td>
                <td><?php echo e($value->angkatan); ?></td>
                <td><?php echo e($value->kelompok); ?></td>
                <td><i class="fa fa-<?php echo e($value->status_aktif == 1 ? 'check' : 'ban'); ?>"></i> <?php echo e($value->status_aktif == 1 ? 'Aktif' : 'Tidak Aktif'); ?></td>
                <td>
                    <button class="btn btn-sm bg-orange" data-toggle="modal" data-target="#modal-default-<?php echo $key; ?>"> <i class="fa fa-pencil"></i> Ubah</button>
                    <form action="<?php echo e(route('siswa.status', $value->id)); ?>" method="POST" style="display: inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <button class="btn btn-sm <?php echo e($value->status_aktif == 1 ? 'bg-black' : 'bg-green'); ?>" onclick="return confirm('Yakin ingin <?php echo e($value->status_aktif == 1 ? 'menonaktifkan' : 'mengaktifkan'); ?> siswa <?php echo e($value->nama); ?>?')"> <?php echo ($value->status_aktif == 1) ? 'Nonaktifkan!' : 'Aktifkan!'; ?></button>
                    </form>
                    <form action="<?php echo e(route('siswa.delete', $value->id)); ?>" method="POST" style="display: inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-sm bg-red" onclick="return confirm('Yakin ingin menghapus siswa <?php echo e($value->nama); ?>?')"> <i class="fa fa-trash"></i> Hapus</button>
                    </form>
                </td>
            </tr>
            <div class="modal fade" id="modal-default-<?php echo $key; ?>">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form action="<?php echo e(route('siswa.update', $value->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <h4 class="modal-title">Ubah Siswa</h4>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="jurusan">Jurusan</label>
                                    <select class="form-control" id="jurusan" name="jurusan_kode" disabled>
                                        <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e($item->id == $value->jurusan_id ? 'selected' : ''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="nis">NIS</label>
                                    <input type="number" class="form-control" id="nis" name="nis" value="<?php echo e($value->nis); ?>" placeholder="[Nomor Induk Siswa]" disabled>
                                </div>
                                <div class="form-group">
                                    <label for="nama">Nama</label>
                                    <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e($value->nama); ?>" placeholder="[Nama Siswa]">
                                </div>
                                <div class="form-group">
                                    <label for="angkatan">Angkatan</label>
                                    <input type="number" disabled min="2010" max="2110" class="form-control" id="angkatan" name="angkatan" value="<?php echo e($value->angkatan); ?>" placeholder="[Angkatan]">
                                </div>
                                <div class="form-group">
                                    <label for="kelompok">Kelas</label>
                                    <input type="text" class="form-control" id="kelompok" name="kelompok" value="<?php echo e($value->kelompok); ?>" placeholder="[Kelompok]">
                                </div>
                                <div class="form-group">
                                    <label for="kurikulum_id">Kurikulum Yang Diikuti</label>
                                    <select class="form-control" id="kurikulum_id" name="kurikulum_id">
                                        <?php
                                            $kurikulumSiswa = collect($kurikulum)->where('jurusan_kode', '=', $value->jurusan_kode)->all();
                                        ?>
                                        <?php $__currentLoopData = $kurikulumSiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemKurikulum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($itemKurikulum->id); ?>"><?php echo e($itemKurikulum->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo e($value->user->email); ?>" placeholder="[Email]">
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-primary">Simpan</button>
                            </div>
                        </div>
                    </form>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
    <!-- /.box-body -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">
    $('#table').DataTable({
        "pageLength": 50
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\siakad-smk-7\resources\views/admin/siswa/index.blade.php ENDPATH**/ ?>